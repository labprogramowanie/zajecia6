﻿using System;
using System.Data;

namespace BibliotekaKlas
{
    public enum Zawody : short
    {
        Pracownik, Informatyk, Lekarz, Nauczyciel
    }
    public class Pracownik
    {
        private string imie;
        private string nazwisko;
        private Data dataUrodzenia;
        private Adres adresZamieszkania;
        private object console;

        public string Imie
        {
            get { return imie; }
            set { imie = value; }
        }
        public string Nazwisko
        {
            get { return nazwisko; }
            set { nazwisko = value; }
        }
        public Data DataUrodzenia
        {
            get { return dataUrodzenia; }
            set { dataUrodzenia = value; }
        }
        public Adres AdresZamieszkania
        {
            get { return adresZamieszkania; }
            set { adresZamieszkania = value; }
        }

        public virtual Zawody Zawod
        {
            get { return Zawody.Pracownik; }
        }

        public Pracownik()
        {
            dataUrodzenia = new Data();
            adresZamieszkania = new Adres();
        }

        public Pracownik(string i, string n)
        {
            imie = i;
            nazwisko = n;
        }
        public Pracownik(Pracownik wzor)
        {
            imie = wzor.imie;
            nazwisko = wzor.nazwisko;

        }

        public virtual Pracownik Clone()
        {
            Pracownik kopia = new Pracownik(this);
            return kopia;
        }

        public override string ToString()
        {
            return imie.ToString() + nazwisko.ToString() + dataUrodzenia.Dzien.ToString() + dataUrodzenia.Miesiac.ToString() + dataUrodzenia.Rok.ToString() + AdresZamieszkania.Ulica.ToString() + AdresZamieszkania.NumerDomu.ToString() + AdresZamieszkania.Miasto.ToString();
        }
        public virtual string FormatWyjsciowy()
        {
            return imie.ToString() +" "+ nazwisko.ToString() +"\n"+ dataUrodzenia.Dzien.ToString() +" "+ dataUrodzenia.Miesiac.ToString()+" " + dataUrodzenia.Rok.ToString()+"\n" + AdresZamieszkania.Ulica.ToString()+" " + AdresZamieszkania.NumerDomu.ToString() +" "+ AdresZamieszkania.Miasto.ToString();

        }
       public  virtual string SzczegolyZawodu()
        {
            return "brak";
        }
        public string DataToString()
        {
            return dataUrodzenia.ToString();
        }
        public string AdresToString()
        {
            return adresZamieszkania.ToString();
        }
        public virtual void OdczytConsole() //using system
        {
            Console.WriteLine("Podaj imie");
            imie = Console.ReadLine();
            Console.WriteLine("Podaj nazwisko");
            nazwisko = Console.ReadLine();
            Console.WriteLine("Podaj date urodzenia");
            Data dataUrodzenia = Data.Parse(Console.ReadLine());
           // dataUrodzenia.Ulica = Console.ReadLine();
            Console.WriteLine("Podaj adres zamieszkania");
            Adres adresZamieszkania = Adres.Parse(Console.ReadLine());
         }
        public virtual void ZapisConsole()
        {
            Console.WriteLine("Imie", imie);
            Console.WriteLine("Nazwisko", nazwisko);
            Console.WriteLine("Data urodzenia", dataUrodzenia);
            Console.WriteLine("Adres zamieszkania", adresZamieszkania);
        }
        public virtual void OdczytXml(DataRow dr) // using System.Data
        {
            ;
        }
    }
}