﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BibliotekaKlas;

namespace wierszPolecen
{
    class Program
    {
        static void Main(string[] args)
        {
            Data obiekt1 = new Data();
            Adres obiekt2 = new Adres();
            obiekt1 = new Pracownik();

        }
    }
}
